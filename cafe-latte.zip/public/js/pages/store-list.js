$(document).ready(function() {
    // Mansory genarate content food store user
    /*
    function mansory(){
        var $container = $('.grid');
        $container.imagesLoaded(function(){
            $container.masonry({
                itemSelector: '.grid-col-item',
                fitWidth: true,
                horizontalOrder: true
            });
        });
    }

    mansory();
    */
})
