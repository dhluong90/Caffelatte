<?php 


// You can find the keys here : https://console.developers.google.com

return array(
    'KEY' => 'AIzaSyBe9dPI_HkbUbuOBr43nl5Sxx8qAm2qw6E'
);