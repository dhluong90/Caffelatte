<?php

return [
    'id' => env('FACEBOOK_APP_ID'),
    'secret' => env('FACCEBOOK_APP_SECRET')
];